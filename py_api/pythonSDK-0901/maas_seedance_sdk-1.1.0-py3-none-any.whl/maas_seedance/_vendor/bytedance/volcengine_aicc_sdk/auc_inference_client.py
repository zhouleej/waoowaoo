import uuid
"""
seedance机密推理客户端
"""
__all__ = ["AUCClient"]

import os
import base64
import requests
import traceback
from urllib.parse import unquote
from cryptography.hazmat.primitives import serialization as crypto_serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend as crypto_default_backend
from bytedance.jeddak_secure_channel.crypto import PrivateKey
from .secure_http_client import SecureHttpClient
from .common.tos_utils import TOSUtils
from .common.error import AICCException
from .common.log import logger
from .secure_http_client import AICCConfig
from .common.aes import decrypt_file


class AUCClient:
    """
    AUC机密推理客户端.
    """

    def __init__(self,
                 base_url: str = "",
                 api_key: str = "",
                 endpoint: str = "",
                 aicc_config: AICCConfig = None,
                 **kwargs):
        self.base_url = base_url
        self.api_key = api_key
        self.endpoint = endpoint
        self.aicc_config = aicc_config
        self.tos_utils = TOSUtils()
        self.kwargs = kwargs
        self.is_secure = self.kwargs.get("is_secure", True)

        if aicc_config:
            self.secure_http_client = SecureHttpClient(aicc_config=aicc_config)
        else:
            if self.is_secure:
                aicc_config = AICCConfig(ra_url=base_url, auth_token=api_key)
                self.secure_http_client = SecureHttpClient(aicc_config=aicc_config)
            else:
                self.secure_http_client = SecureHttpClient()

        # 是否开启AUC文件加密, 默认加密
        self.is_enable_auc_encrypt = str(self.kwargs.get("is_enable_auc_encrypt", True)).lower() == "true"

        # AUC文件的存储位置, 目前仅支持火山TOS
        self.auc_file_storage_location = self.kwargs.get("auc_file_storage_location", "TOS").upper()

        self.auc_file_encrypt_pub_key_content = None
        self.auc_file_encrypt_priv_key_content = None

        self.auc_file_encrypt_priv_key: PrivateKey = None

        self.timeout = self.kwargs.get("timeout", 120.0)

        # API Endpoints
        self.CREATE_TASK_URL = "/auc/lark/submit"
        self.QUERY_TASK_URL = "/auc/lark/query"

    def _build_common_headers(self, request_id: str) -> dict[str, str]:
        if not request_id:
            request_id = str(uuid.uuid4())

        return {
            "Content-Type": "application/json",
            "X-Api-App-Key": self.endpoint,
            "Authorization": f"Bearer {self.api_key}",
            "X-Request-Id": request_id,
        }

    def _get_base_url(self):
        """
        Get base URL with trailing slash removed
        """
        return self.base_url.rstrip("/")

    def generate_key_pair(self, pub_key_path: str = "", priv_key_path: str = ""):
        """
        Generate RSA 4096 key pair and save to files

        Args:
            pub_key_path: Path to save public key
            priv_key_path: Path to save private key

        Returns:
            Tuple of (public_key_path, private_key_path)
        """
        try:
            # Generate RSA key pair
            key = rsa.generate_private_key(
                backend=crypto_default_backend(),
                public_exponent=65537,
                key_size=4096
            )

            # Save private key
            private_key = key.private_bytes(
                crypto_serialization.Encoding.PEM,
                crypto_serialization.PrivateFormat.PKCS8,
                crypto_serialization.NoEncryption()
            )
            with open(priv_key_path, 'wb') as f:
                f.write(private_key)

            # Save public key
            public_key = key.public_key().public_bytes(
                crypto_serialization.Encoding.PEM,
                crypto_serialization.PublicFormat.SubjectPublicKeyInfo
            )
            with open(pub_key_path, 'wb') as f:
                f.write(public_key)
        except Exception as e:
            logger.error(f"[Error] Failed to generate key pair: {e}")
            raise AICCException("Failed to generate RSA key pair") from e

    def set_file_encrypt_key(self, pub_key_path: str = "", priv_key_path: str = ""):
        """
        Set auc file encrypt key
        Args:
            pub_key_path: Public key for encrypt
            priv_key_path: Private key for decrypt
        """
        if os.path.exists(pub_key_path):
            with open(pub_key_path, 'r') as f:
                content = f.read()
                if '-----BEGIN' in content and '-----END' in content:
                    self.auc_file_encrypt_pub_key_content = content

        if os.path.exists(priv_key_path):
            with open(priv_key_path, 'r') as f:
                content = f.read()
                if '-----BEGIN' in content and '-----END' in content:
                    self.auc_file_encrypt_priv_key_content = content
                    self.auc_file_encrypt_priv_key = \
                        PrivateKey.from_private_pem(self.auc_file_encrypt_priv_key_content)

    def create_task(self, data: dict, custom_header: dict = None, request_id: str = "") -> str:
        """
        :param data:
        :param custom_header:
        :return:
        """
        if not data:
            raise AICCException("data must be provided")

        if "model" not in data:
            data["model"] = self.endpoint

        base_url = self._get_base_url()
        url = f"{base_url}{self.CREATE_TASK_URL}"

        headers = self._build_common_headers(request_id)
        if custom_header:
            headers.update(custom_header)

        # Add encryption headers if provided
        if self.is_enable_auc_encrypt:
            if not self.auc_file_encrypt_pub_key_content or not self.auc_file_encrypt_priv_key_content:
                raise AICCException("pub_key and priv_key must be provided when Is-Enable-Encrypt is 'true'")

            headers["Enable-TOS-Content-Result-Encryption"] = str(self.is_enable_auc_encrypt).lower()
            headers["X-Encryption-Algorithm"] = "RSA_OAEP_4096_AES_256"
            if self.auc_file_encrypt_pub_key_content:
                # Base64 encode the PEM public key for safe HTTP header transmission
                # This avoids issues with newlines and special characters in headers
                pk_base64 = base64.b64encode(self.auc_file_encrypt_pub_key_content.encode()).decode()
                headers["PK"] = pk_base64

        # logger.info(f"[Request] url: {url}, headers: {headers}, data: {data}")

        response = self.secure_http_client.post(url, headers=headers, json=data, timeout=self.timeout)
        if response.status_code == 200:
            result = response.json()
            task_id = result.get("Data", {}).get("TaskID", "")
            return task_id
        else:
            logger.error(f"[Error] url: {url}, response: {response.text}")
            return ""

    def query_task(self, task_id: str, request_id: str = "") -> dict:
        """
        Query auc task
        API: POST /auc/lark/query
        """

        if not task_id:
            raise AICCException("task_id must be provided")

        base_url = self._get_base_url()
        url = f"{base_url}{self.QUERY_TASK_URL}"

        headers = self._build_common_headers(request_id)
        payload = {"TaskID": task_id}

        response = self.secure_http_client.post(url, headers=headers, json=payload, timeout=self.timeout)
        if response.status_code == 200:
            result = response.json()
            return result
        else:
            try:
                result = response.json()
                return result
            except Exception as e:
                logger.error(f"[Error] url: {url}, Exception={e}")
                raise AICCException("Failed to query auc task")

    def download_file(self, task_id: str, auc_file_path: str) -> bool:
        """
        Download and decrypt encrypted auc
        This function polls the task status until it succeeds, then downloads
        and decrypts the auc using the provided private key.
        Args:
            task_id: AUC generation task ID
            auc_file_path: Directory to save decrypted auc

        Returns:
            True if download succeeded, False otherwise
        """
        if not task_id:
            raise AICCException("task_id must be provided")

        if not auc_file_path:
            raise AICCException("auc_file_path must be provided")

        task_info = self.query_task(task_id)
        status = task_info.get("Data", {}).get("Status", "")
        if not status:
            logger.error(f"task status is null, task_id={task_id}, query_task return {task_info}")
            raise AICCException("task status is null")
        if status != "success":
            logger.info(f"task status is not success, task_id={task_id}, status={status}")
            return False

        result = task_info.get("Data", {}).get("Result") or {}
        for label, key in (
            ("AudioTranscriptionFile", "AudioTranscriptionFile"),
            ("SummarizationFile", "SummarizationFile"),
            ("ChapterFile", "ChapterFile"),
            ("InformationExtractionFile", "InformationExtractionFile"),
            ("TranslationFile", "TranslationFile"),
        ):
            file_url = result.get(key, "")
            if file_url:
                local_file_path = f"./{auc_file_path}_{label}.json"
                self.download_file_by_url(file_url, local_file_path)

    def download_file_by_url(self, file_url: str, local_file_path: str) -> bool:
        """
        Download auc file
        Args:
            file_url: File file_url
            auc_file_path: Directory to save auc file

        Returns:
            Path to auc file, or None if failed
        """
        if not file_url:
            raise AICCException("file_url must be provided")

        if not local_file_path:
            raise AICCException("local_file_path must be provided")

        if os.path.exists(local_file_path) and os.path.getsize(local_file_path) > 0:
            logger.error(f"[Error] File {local_file_path} already exists and is not empty")
            return False

        try:
            response = requests.get(file_url, stream=True)
            with open(local_file_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

            if self.is_enable_auc_encrypt:
                if not self.auc_file_encrypt_priv_key:
                    logger.error("[Error] No private key set, cannot decrypt encrypted auc")
                    return False

                headers = response.headers
                encrypted_key = headers.get("x-tos-meta-enc-dek")
                if encrypted_key:
                    try:
                        encrypted_key_bytes = base64.b64decode(unquote(encrypted_key))
                        encrypted_key = self.auc_file_encrypt_priv_key.decrypt(encrypted_key_bytes)
                        tmp_file_path = local_file_path + ".tmp"
                        decrypt_file(encrypted_key, local_file_path, tmp_file_path, 'b')
                        os.remove(local_file_path)
                        os.rename(tmp_file_path, local_file_path)
                    except Exception as e:
                        logger.error(f"[Error] Failed to decode encrypted_key: {e}")
                        traceback.print_exc()
                        return False
        except Exception as e:
            logger.error(f"[Error] Download failed: {e}")
            traceback.print_exc()
            return False
        return True
