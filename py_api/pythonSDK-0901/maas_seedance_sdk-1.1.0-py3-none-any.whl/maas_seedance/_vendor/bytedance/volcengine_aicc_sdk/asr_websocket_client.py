"""
流式语音识别大模型机密推理客户端
"""
__all__ = ["AsrWebSocketClient"]

from ..jeddak_secure_channel.crypto import AesKey

"""
SAUC WebSocket demo client.

Usage:
1. Minimal run:
   python3 tests/sauc_websocket_demo.py --file tests/test-sound.mp3 --stop-on-first-result

2. Override any request fields with inline JSON:
   python3 tests/sauc_websocket_demo.py --file tests/test-sound.mp3 \
     --request-json '{"request":{"enable_nonstream":true,"show_utterances":true}}'

3. Override any request fields with a JSON file:
   python3 tests/sauc_websocket_demo.py --file tests/test-sound.mp3 \
     --request-json-file /path/to/sauc_request.json

Notes:
- CLI keeps only commonly needed options.
- Any SAUC full client request fields can still be passed through JSON overrides.
"""

import io
import json
import gzip
import subprocess
import struct
import threading
import time
import uuid
import wave
from dataclasses import dataclass
from typing import Any, Dict, Iterator, List, Optional, Tuple

try:
    from websocket import WebSocket, WebSocketConnectionClosedException, WebSocketTimeoutException, create_connection
except ImportError:
    try:
        from websocket._core import WebSocket
        from websocket._exceptions import WebSocketConnectionClosedException, WebSocketTimeoutException
        from websocket._app import create_connection
    except ImportError:
        WebSocket = object
        WebSocketConnectionClosedException = ConnectionError
        WebSocketTimeoutException = TimeoutError
        create_connection = None
import bytedance.jeddak_secure_channel as jsc
from .common.log import logger
from .secure_http_client import AICCConfig

# 常量定义
DEFAULT_SAMPLE_RATE = 16000
DEFAULT_MODEL_NAME = "bigmodel"
INTER_PACKET_DRAIN_TIMEOUT_SECONDS = 0.02
APP_PING = "__aicc_ws_ping__"
APP_PONG = "__aicc_ws_pong__"
DEFAULT_FULL_CLIENT_REQUEST = {
    "audio": {
        "format": "wav",
        "codec": "raw",
        "rate": DEFAULT_SAMPLE_RATE,
        "bits": 16,
        "channel": 1,
    },
    "request": {
        "model_name": DEFAULT_MODEL_NAME,
    },
}


class ProtocolVersion:
    V1 = 0b0001


class MessageType:
    CLIENT_FULL_REQUEST = 0b0001
    CLIENT_AUDIO_ONLY_REQUEST = 0b0010
    SERVER_FULL_RESPONSE = 0b1001
    SERVER_ERROR_RESPONSE = 0b1111


class MessageTypeSpecificFlags:
    NO_SEQUENCE = 0b0000
    POS_SEQUENCE = 0b0001
    NEG_SEQUENCE = 0b0010
    NEG_WITH_SEQUENCE = 0b0011


class SerializationType:
    NO_SERIALIZATION = 0b0000
    JSON = 0b0001


class CompressionType:
    GZIP = 0b0001


class AsrRequestHeader:
    def __init__(self):
        self.message_type = MessageType.CLIENT_FULL_REQUEST
        self.message_type_specific_flags = MessageTypeSpecificFlags.POS_SEQUENCE
        self.serialization_type = SerializationType.JSON
        self.compression_type = CompressionType.GZIP
        self.reserved_data = bytes([0x00])

    def with_message_type(self, message_type: int) -> "AsrRequestHeader":
        self.message_type = message_type
        return self

    def with_message_type_specific_flags(self, flags: int) -> "AsrRequestHeader":
        self.message_type_specific_flags = flags
        return self

    def with_serialization_type(self, serialization_type: int) -> "AsrRequestHeader":
        self.serialization_type = serialization_type
        return self

    def with_compression_type(self, compression_type: int) -> "AsrRequestHeader":
        self.compression_type = compression_type
        return self

    def with_reserved_data(self, reserved_data: bytes) -> "AsrRequestHeader":
        self.reserved_data = reserved_data
        return self

    def to_bytes(self) -> bytes:
        header = bytearray()
        header.append((ProtocolVersion.V1 << 4) | 1)
        header.append((self.message_type << 4) | self.message_type_specific_flags)
        header.append((self.serialization_type << 4) | self.compression_type)
        header.extend(self.reserved_data)
        return bytes(header)

    @staticmethod
    def default_header() -> "AsrRequestHeader":
        return AsrRequestHeader()


@dataclass
class AsrResponse:
    code: int = 0
    event: int = 0
    is_last_package: bool = False
    payload_sequence: int = 0
    payload_size: int = 0
    payload_msg: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "code": self.code,
            "event": self.event,
            "is_last_package": self.is_last_package,
            "payload_sequence": self.payload_sequence,
            "payload_size": self.payload_size,
            "payload_msg": self.payload_msg,
        }

    def is_terminal(self) -> bool:
        return self.is_last_package or self.code != 0


class _SessionContext:
    """Holds per-execution state to support concurrent access."""

    def __init__(self, client: "AsrWebSocketClient"):
        self.client = client
        self.conn: Optional[WebSocket] = None
        self.seq: int = 1
        self.encrypt_key = None
        self.aes_key = AesKey.generate() if client.jsc_client else None

    def connect(self) -> None:
        headers = self.client._build_auth_headers(
            self.client.api_key, self.client.resource_id, self.client._build_connection_headers()
        )
        self.conn = create_connection(
            self.client.base_url,
            header=[f"{key}: {value}" for key, value in headers.items()],
            timeout=self.client.connect_timeout,
        )
        self.conn.settimeout(self.client.receive_timeout)
        logger.info("Connected to %s", self.client.base_url)

    def close(self) -> None:
        if self.conn is not None:
            self.conn.close()
            self.conn = None

    def encode_outbound_frame(self, payload: bytes) -> bytes:
        if self.client.jsc_client:
            msg, encrypt_key = self.client.jsc_client.encrypt_with_response(payload, self.aes_key)
            if encrypt_key:
                self.encrypt_key = encrypt_key
            if isinstance(msg, str):
                msg = msg.encode("utf-8")
            return msg
        else:
            return payload

    def decode_inbound_frame(self, payload: bytes) -> bytes:
        if self.encrypt_key:
            msg = self.encrypt_key.decrypt(payload)
            if isinstance(msg, str):
                msg = msg.encode("utf-8")
            return msg
        else:
            return payload

    def send_binary(self, payload: bytes) -> None:
        if self.conn is None:
            raise RuntimeError("WebSocket connection is not established")
        self.conn.send_binary(self.encode_outbound_frame(payload))

    def send_text(self, payload: str) -> None:
        if self.conn is None:
            raise RuntimeError("WebSocket connection is not established")
        self.conn.send(payload)

    def send_app_pong(self) -> None:
        payload = json.dumps({"type": APP_PONG}, separators=(",", ":"))
        if self.client.jsc_client:
            self.send_binary(payload.encode("utf-8"))
            logger.info("[WS_HEARTBEAT] client sent encrypted app pong")
            return
        self.send_text(payload)
        logger.info("[WS_HEARTBEAT] client sent app pong")

    def _maybe_handle_control_payload(self, payload) -> bool:
        text: str
        if isinstance(payload, bytes):
            try:
                text = payload.decode("utf-8")
            except UnicodeDecodeError:
                return False
        else:
            text = payload

        try:
            payload_obj = json.loads(text)
        except (TypeError, json.JSONDecodeError):
            return False

        if not isinstance(payload_obj, dict):
            return False

        message_type = payload_obj.get("type")
        if message_type == APP_PING:
            logger.info("[WS_HEARTBEAT] client received app ping")
            self.send_app_pong()
            return True
        if message_type == APP_PONG:
            logger.info("[WS_HEARTBEAT] client received app pong")
            return True
        return False

    def recv_one(self, timeout: float) -> Optional[AsrResponse]:
        if self.conn is None:
            raise RuntimeError("WebSocket connection is not established")

        deadline = time.monotonic() + max(timeout, 0.0)
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return None

            self.conn.settimeout(remaining)
            try:
                message = self.conn.recv()
            except WebSocketTimeoutException:
                return None
            except WebSocketConnectionClosedException as exc:
                raise RuntimeError("WebSocket connection closed unexpectedly") from exc
            finally:
                self.conn.settimeout(self.client.receive_timeout)

            if isinstance(message, str):
                if self._maybe_handle_control_payload(message):
                    continue
                logger.info("Received text message: %s", message)
                continue

            decoded_message = self.decode_inbound_frame(message)
            if self._maybe_handle_control_payload(decoded_message):
                continue
            return self.client._parse_response(decoded_message)

    def drain_messages(self, timeout: float) -> Iterator[AsrResponse]:
        while True:
            response = self.recv_one(timeout)
            if response is None:
                return
            yield response
            timeout = 0.1

    def send_full_client_request(self) -> Iterator[AsrResponse]:
        self.send_binary(
            self.client._build_full_client_request(
                self.seq,
                model_name=self.client.model_name,
                enable_nonstream=self.client.enable_nonstream,
                enable_itn=self.client.enable_itn,
                enable_punc=self.client.enable_punc,
                enable_ddc=self.client.enable_ddc,
                show_utterances=self.client.show_utterances,
                result_type=self.client.result_type,
                enable_accelerate_text=self.client.enable_accelerate_text,
                vad_segment_duration=self.client.vad_segment_duration,
                full_client_request_overrides=self.client.full_client_request_overrides,
            )
        )
        logger.info(f"Sent full client request with seq: {self.seq}")
        self.seq += 1
        yield from self.drain_messages(self.client.connect_timeout)

    def send_audio_stream(self, content: bytes, segment_size: int) -> Iterator[AsrResponse]:
        audio_segments = self.client._split_audio(content, segment_size)
        total_segments = len(audio_segments)

        for index, segment in enumerate(audio_segments):
            is_last = index == total_segments - 1
            request = self.client._build_audio_only_request(self.seq, segment, is_last=is_last)
            self.send_binary(request)
            logger.debug(f"Sent audio segment with seq: {self.seq} (last: {is_last})")
            if not is_last:
                self.seq += 1

            if self.client.segment_duration > 0:
                time.sleep(self.client.segment_duration / 1000)

            yield from self.drain_messages(INTER_PACKET_DRAIN_TIMEOUT_SECONDS)

    def receive_final_messages(self) -> Iterator[AsrResponse]:
        deadline = time.monotonic() + self.client.final_wait_seconds
        while time.monotonic() < deadline:
            response = self.recv_one(min(self.client.receive_timeout, deadline - time.monotonic()))
            if response is None:
                continue
            yield response
            if response.is_terminal():
                return


class AsrWebSocketClient:
    _jsc_client_cache: Dict[str, Any] = {}
    _jsc_client_lock = threading.Lock()

    def __init__(
            self,
            base_url: str = "",
            api_key: str = "",
            endpoint: str = "",
            aicc_config: AICCConfig = None,
            **kwargs
    ):
        self.base_url = base_url
        self.api_key = api_key
        self.endpoint = endpoint
        self.resource_id = self.endpoint
        self.aicc_config = aicc_config
        self.kwargs = kwargs

        self.seq = self.kwargs.get("seq", 1)
        self.segment_duration = self.kwargs.get("segment_duration", 200)

        self.model_name = self.kwargs.get("model_name", None)
        self.enable_nonstream = self.kwargs.get("enable_nonstream", None)
        self.enable_itn = self.kwargs.get("enable_itn", None)
        self.enable_punc = self.kwargs.get("enable_punc", None)
        self.enable_ddc = self.kwargs.get("enable_ddc", None)
        self.show_utterances = self.kwargs.get("show_utterances", None)
        self.result_type = self.kwargs.get("result_type", None)
        self.enable_accelerate_text = self.kwargs.get("enable_accelerate_text", None)
        self.vad_segment_duration = self.kwargs.get("vad_segment_duration", None)
        self.full_client_request_overrides = self.kwargs.get("full_client_request_overrides", {})
        self.extra_headers = self.kwargs.get("extra_headers", {})
        self.connect_timeout = self.kwargs.get("connect_timeout", 10.0)
        self.receive_timeout = self.kwargs.get("receive_timeout", 1.0)
        self.final_wait_seconds = self.kwargs.get("final_wait_seconds", 15.0)
        self.is_secure = self.kwargs.get("is_secure", True)
        self.enable_app_heartbeat = self.kwargs.get("enable_app_heartbeat", True)

        # 将http地址转成wss地址
        if self.base_url.startswith("https://"):
            self.base_url = self.base_url.replace("https", "wss")
        elif self.base_url.startswith("http://"):
            self.base_url = self.base_url.replace("http", "wss")

        asr_suffix = self.kwargs.get("asr_suffix", "/sauc/bigmodel_async")
        if not self.base_url.endswith(asr_suffix):
            self.base_url = self.base_url + asr_suffix

        self.jsc_client = None
        if not self.aicc_config:
            if self.is_secure:
                self.aicc_config = AICCConfig(ra_url=base_url, auth_token=api_key)
        if self.aicc_config:
            self.jsc_client = self._get_or_create_jsc_client(aicc_config=self.aicc_config)

        self.AICC_SDK_VERSION = "0.1.0"

    @classmethod
    def _get_or_create_jsc_client(cls, config_dict: Dict[str, Any] = None, aicc_config: AICCConfig = None) -> Any:
        if aicc_config is not None:
            config_dict = aicc_config.get_jsc_config()
        cache_key = json.dumps(config_dict, sort_keys=True)
        if cache_key in cls._jsc_client_cache:
            return cls._jsc_client_cache[cache_key]
        with cls._jsc_client_lock:
            if cache_key in cls._jsc_client_cache:
                return cls._jsc_client_cache[cache_key]
            secure_channel_config = jsc.ClientConfig.from_dict(config_dict)
            client = jsc.Client(secure_channel_config)
            cls._jsc_client_cache[cache_key] = client
            return client

    def _build_auth_headers(
            self,
            api_key: str,
            resource_id: str,
            extra_headers: Optional[Dict[str, str]] = None,
    ) -> Dict[str, str]:
        headers = {
            "X-Api-Resource-Id": resource_id,
            "X-Api-Request-Id": str(uuid.uuid4()),
            "X-Api-Connect-Id": str(uuid.uuid4()),
            "X-Api-Sequence": "-1",
            "X-Api-Key": api_key,
            "Authorization": f"Bearer {api_key}",
        }
        if extra_headers:
            headers.update(extra_headers)
        return headers

    def _convert_audio_to_wav_bytes(self, audio_path: str, sample_rate: int = DEFAULT_SAMPLE_RATE) -> bytes:
        cmd = [
            "ffmpeg",
            "-v",
            "quiet",
            "-y",
            "-i",
            audio_path,
            "-acodec",
            "pcm_s16le",
            "-ac",
            "1",
            "-ar",
            str(sample_rate),
            "-f",
            "wav",
            "-",
        ]
        try:
            result = subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except subprocess.CalledProcessError as exc:
            message = exc.stderr.decode("utf-8", errors="replace")
            raise RuntimeError(f"Audio conversion failed: {message}") from exc

        try:
            with open("converted.wav", "wb") as file_handle:
                file_handle.write(result.stdout)
        except OSError as exc:
            logger.warning("Failed to save converted.wav: %s", exc)

        return result.stdout

    def _is_wav_file(self, data: bytes) -> bool:
        if len(data) < 12:
            return False
        return data[:4] == b"RIFF" and data[8:12] == b"WAVE"

    def _read_audio_data(self, file_path: str) -> bytes:
        with open(file_path, "rb") as file_handle:
            content = file_handle.read()

        if self._is_wav_file(content):
            return content

        logger.info("Converting audio to WAV format...")
        return self._convert_audio_to_wav_bytes(file_path, DEFAULT_SAMPLE_RATE)

    def _read_wav_info(self, data: bytes) -> Tuple[int, int, int, int]:
        try:
            with wave.open(io.BytesIO(data), "rb") as wav_file:
                channel_num = wav_file.getnchannels()
                samp_width = wav_file.getsampwidth()
                frame_rate = wav_file.getframerate()
                frame_count = wav_file.getnframes()
        except wave.Error as exc:
            raise ValueError(f"Invalid WAV file: {exc}") from exc

        return channel_num, samp_width, frame_rate, frame_count

    def _get_segment_size(self, content: bytes) -> int:
        channel_num, samp_width, frame_rate, _ = self._read_wav_info(content)
        size_per_second = channel_num * samp_width * frame_rate
        return size_per_second * self.segment_duration // 1000

    def _build_connection_headers(self) -> Dict[str, str]:
        headers = dict(self.extra_headers)
        if self.enable_app_heartbeat:
            headers["X-AICC-App-Heartbeat"] = "true"
        if self.aicc_config:
            headers["X-AICC-Encryption-Enable"] = "true"
            headers["X-AICC-Encryption-SDK"] = "aicc"
            headers["X-AICC-Encryption-Version"] = self.AICC_SDK_VERSION
        return headers

    def _gzip_compress(self, data: bytes) -> bytes:
        return gzip.compress(data)

    def _gzip_decompress(self, data: bytes) -> bytes:
        return gzip.decompress(data)

    def _parse_response(self, message: bytes) -> AsrResponse:
        if not message:
            raise ValueError("Cannot parse an empty websocket frame")

        response = AsrResponse()
        header_size = message[0] & 0x0F
        message_type = message[1] >> 4
        message_type_specific_flags = message[1] & 0x0F
        serialization_method = message[2] >> 4
        message_compression = message[2] & 0x0F
        payload = message[header_size * 4:]

        if message_type_specific_flags & 0x01:
            response.payload_sequence = struct.unpack(">i", payload[:4])[0]
            payload = payload[4:]
        if message_type_specific_flags & 0x02:
            response.is_last_package = True
        if message_type_specific_flags & 0x04:
            response.event = struct.unpack(">i", payload[:4])[0]
            payload = payload[4:]

        if message_type == MessageType.SERVER_FULL_RESPONSE:
            response.payload_size = struct.unpack(">I", payload[:4])[0]
            payload = payload[4:]
        elif message_type == MessageType.SERVER_ERROR_RESPONSE:
            response.code = struct.unpack(">i", payload[:4])[0]
            response.payload_size = struct.unpack(">I", payload[4:8])[0]
            payload = payload[8:]

        if not payload:
            return response

        if message_compression == CompressionType.GZIP:
            try:
                payload = self._gzip_decompress(payload)
            except Exception as exc:
                logger.error("Failed to decompress payload: %s", exc)
                return response

        try:
            if serialization_method == SerializationType.JSON:
                response.payload_msg = json.loads(payload.decode("utf-8"))
        except Exception as exc:
            logger.error("Failed to parse payload: %s", exc)

        return response

    def _deep_merge_dict(self, base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
        merged = dict(base)
        for key, value in override.items():
            if isinstance(value, dict) and isinstance(merged.get(key), dict):
                merged[key] = self._deep_merge_dict(merged[key], value)
            else:
                merged[key] = value
        return merged

    def _build_full_request_payload(
            self,
            *,
            model_name: Optional[str] = None,
            enable_nonstream: Optional[bool] = None,
            enable_itn: Optional[bool] = None,
            enable_punc: Optional[bool] = None,
            enable_ddc: Optional[bool] = None,
            show_utterances: Optional[bool] = None,
            result_type: Optional[str] = None,
            enable_accelerate_text: Optional[bool] = None,
            vad_segment_duration: Optional[int] = None,
            full_client_request_overrides: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        payload = self._deep_merge_dict(DEFAULT_FULL_CLIENT_REQUEST, full_client_request_overrides or {})
        request_payload = dict(payload.get("request", {}))

        if model_name is not None:
            request_payload["model_name"] = model_name
        if enable_nonstream is not None:
            request_payload["enable_nonstream"] = enable_nonstream
        if enable_itn is not None:
            request_payload["enable_itn"] = enable_itn
        if enable_punc is not None:
            request_payload["enable_punc"] = enable_punc
        if enable_ddc is not None:
            request_payload["enable_ddc"] = enable_ddc
        if show_utterances is not None:
            request_payload["show_utterances"] = show_utterances
        if result_type is not None:
            request_payload["result_type"] = result_type
        if enable_accelerate_text is not None:
            request_payload["enable_accelerate_text"] = enable_accelerate_text
        if vad_segment_duration is not None:
            request_payload["vad_segment_duration"] = vad_segment_duration

        payload["request"] = request_payload
        return payload

    def _build_full_client_request(
            self,
            seq: int,
            *,
            model_name: Optional[str] = None,
            enable_nonstream: Optional[bool] = None,
            enable_itn: Optional[bool] = None,
            enable_punc: Optional[bool] = None,
            enable_ddc: Optional[bool] = None,
            show_utterances: Optional[bool] = None,
            result_type: Optional[str] = None,
            enable_accelerate_text: Optional[bool] = None,
            vad_segment_duration: Optional[int] = None,
            full_client_request_overrides: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        header = AsrRequestHeader.default_header().with_message_type_specific_flags(MessageTypeSpecificFlags.POS_SEQUENCE)
        payload = self._build_full_request_payload(
            model_name=model_name,
            enable_nonstream=enable_nonstream,
            enable_itn=enable_itn,
            enable_punc=enable_punc,
            enable_ddc=enable_ddc,
            show_utterances=show_utterances,
            result_type=result_type,
            enable_accelerate_text=enable_accelerate_text,
            vad_segment_duration=vad_segment_duration,
            full_client_request_overrides=full_client_request_overrides,
        )
        payload_bytes = json.dumps(payload).encode("utf-8")
        compressed_payload = self._gzip_compress(payload_bytes)

        request = bytearray()
        request.extend(header.to_bytes())
        request.extend(struct.pack(">i", seq))
        request.extend(struct.pack(">I", len(compressed_payload)))
        request.extend(compressed_payload)
        return bytes(request)

    def _split_audio(self, data: bytes, segment_size: int) -> List[bytes]:
        if segment_size <= 0:
            return []
        return [data[index:index + segment_size] for index in range(0, len(data), segment_size)]

    def _build_audio_only_request(self, seq: int, segment: bytes, is_last: bool = False) -> bytes:
        header = AsrRequestHeader.default_header()
        if is_last:
            header.with_message_type_specific_flags(MessageTypeSpecificFlags.NEG_WITH_SEQUENCE)
            seq = -seq
        else:
            header.with_message_type_specific_flags(MessageTypeSpecificFlags.POS_SEQUENCE)
        header.with_message_type(MessageType.CLIENT_AUDIO_ONLY_REQUEST)

        request = bytearray()
        request.extend(header.to_bytes())
        request.extend(struct.pack(">i", seq))

        compressed_segment = self._gzip_compress(segment)
        request.extend(struct.pack(">I", len(compressed_segment)))
        request.extend(compressed_segment)
        return bytes(request)

    def execute(self, file_path: str) -> Iterator[AsrResponse]:
        if not file_path:
            raise ValueError("File path is empty")
        if not self.base_url or not (self.base_url.startswith("wss://") or self.base_url.startswith("ws://")):
            raise ValueError("Base URL is empty or invalid (must start with wss:// or ws://)")
        if not self.endpoint:
            raise ValueError("Endpoint is empty")
        if not self.api_key:
            raise ValueError("API key is empty")

        session = _SessionContext(self)

        content = self._read_audio_data(file_path)
        segment_size = self._get_segment_size(content)

        try:
            session.connect()

            for response in session.send_full_client_request():
                yield response
                if response.is_terminal():
                    return

            for response in session.send_audio_stream(content, segment_size):
                yield response
                if response.is_terminal():
                    return

            yield from session.receive_final_messages()
        finally:
            session.close()
