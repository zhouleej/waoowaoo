"""
seedream机密推理客户端
"""
__all__ = ["SeedreamClient"]

import os
import uuid
import base64
import traceback
from urllib.parse import unquote
from cryptography.hazmat.primitives import serialization as crypto_serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend as crypto_default_backend
from bytedance.jeddak_secure_channel.crypto import PrivateKey
from .secure_http_client import SecureHttpClient
from .common.error import AICCException
from .common.log import logger
from .secure_http_client import AICCConfig
from .common.aes import decrypt_file


class SeedreamClient:

    def __init__(self,
                 base_url: str = "",
                 api_key: str = "",
                 endpoint: str = "",
                 aicc_config: AICCConfig = None,
                 **kwargs):
        self.base_url = base_url
        self.api_key = api_key
        self.endpoint = endpoint
        self.aicc_config = aicc_config
        self.kwargs = kwargs
        self.is_secure = self.kwargs.get("is_secure", True)

        if aicc_config:
            self.secure_http_client = SecureHttpClient(aicc_config=aicc_config)
        else:
            if self.is_secure:
                aicc_config = AICCConfig(ra_url=base_url, auth_token=api_key)
                self.secure_http_client = SecureHttpClient(aicc_config=aicc_config)
            else:
                self.secure_http_client = SecureHttpClient()

        self.is_enable_image_encrypt = str(self.kwargs.get("is_enable_image_encrypt", True)).lower() == "true"

        self.image_file_encrypt_pub_key_content = None
        self.image_file_encrypt_priv_key_content = None

        self.image_file_encrypt_priv_key: PrivateKey = None

        self.timeout = self.kwargs.get("timeout", 120.0)

        self.CREATE_IMAGE_URL = "/images/generations"

    def _get_base_url(self):
        return self.base_url.rstrip("/")

    def _build_common_headers(self, request_id: str = "") -> dict[str, str]:
        if not request_id:
            request_id = str(uuid.uuid4())

        return {
            "Content-Type": "application/json",
            "X-Api-App-Key": self.endpoint,
            "Authorization": f"Bearer {self.api_key}",
            "X-Request-Id": request_id,
        }

    def generate_key_pair(self, pub_key_path: str = "", priv_key_path: str = ""):
        try:
            key = rsa.generate_private_key(
                backend=crypto_default_backend(),
                public_exponent=65537,
                key_size=4096
            )

            private_key = key.private_bytes(
                crypto_serialization.Encoding.PEM,
                crypto_serialization.PrivateFormat.PKCS8,
                crypto_serialization.NoEncryption()
            )
            with open(priv_key_path, 'wb') as f:
                f.write(private_key)

            public_key = key.public_key().public_bytes(
                crypto_serialization.Encoding.PEM,
                crypto_serialization.PublicFormat.SubjectPublicKeyInfo
            )
            with open(pub_key_path, 'wb') as f:
                f.write(public_key)
        except Exception as e:
            logger.error(f"[Error] Failed to generate key pair: {e}")
            raise AICCException("Failed to generate RSA key pair") from e

    def set_image_encrypt_key(self, pub_key_path: str = "", priv_key_path: str = ""):
        if os.path.exists(pub_key_path):
            with open(pub_key_path, 'r') as f:
                content = f.read()
                if '-----BEGIN' in content and '-----END' in content:
                    self.image_file_encrypt_pub_key_content = content

        if os.path.exists(priv_key_path):
            with open(priv_key_path, 'r') as f:
                content = f.read()
                if '-----BEGIN' in content and '-----END' in content:
                    self.image_file_encrypt_priv_key_content = content
                    self.image_file_encrypt_priv_key = \
                        PrivateKey.from_private_pem(self.image_file_encrypt_priv_key_content)

    def create_image(self, data: dict, custom_header: dict = None, request_id: str = ""):
        if not data:
            raise AICCException("data must be provided")

        if "model" not in data:
            data["model"] = self.endpoint

        base_url = self._get_base_url()
        url = f"{base_url}{self.CREATE_IMAGE_URL}"

        headers = self._build_common_headers(request_id)
        if custom_header:
            headers.update(custom_header)

        if self.is_enable_image_encrypt:
            if not self.image_file_encrypt_pub_key_content or not self.image_file_encrypt_priv_key_content:
                raise AICCException("pub_key and priv_key must be provided when Is-Enable-Encrypt is 'true'")

            headers["Enable-TOS-Content-Result-Encryption"] = str(self.is_enable_image_encrypt).lower()
            headers["X-Encryption-Algorithm"] = "RSA_OAEP_4096_AES_256"
            if self.image_file_encrypt_pub_key_content:
                pk_base64 = base64.b64encode(self.image_file_encrypt_pub_key_content.encode()).decode()
                headers["PK"] = pk_base64

        stream = data.get("stream", False)
        if stream:
            return self.secure_http_client.send(
                self.secure_http_client.build_request("POST", url, headers=headers, json=data, timeout=self.timeout),
                stream=True,
            )

        response = self.secure_http_client.post(url, headers=headers, json=data, timeout=self.timeout)
        if response.status_code == 200:
            return response.json()
        else:
            logger.error(f"[Error] url: {url}, response: {response.text}")
            try:
                return response.json()
            except Exception:
                raise AICCException(f"Failed to create image, status_code={response.status_code}")

    def create_image_by_prompt(self, prompt: str, custom_header: dict = None, request_id: str = "",
                               size: str = "1024x1024", n: int = 1, response_format: str = "url",
                               stream: bool = False, extra_body: dict = None):
        if not prompt:
            raise AICCException("prompt must be provided")

        data = {
            "model": self.endpoint,
            "prompt": prompt,
            "size": size,
            "n": n,
            "response_format": response_format,
        }
        if stream:
            data["stream"] = True
        if extra_body:
            data.update(extra_body)
        return self.create_image(data, custom_header, request_id)

    def download_image(self, image_url: str, local_file_path: str) -> bool:
        if not image_url:
            raise AICCException("image_url must be provided")

        if not local_file_path:
            raise AICCException("local_file_path must be provided")

        if os.path.exists(local_file_path) and os.path.getsize(local_file_path) > 0:
            logger.error(f"[Error] File {local_file_path} already exists and is not empty")
            return False

        try:
            import requests as req
            response = req.get(image_url, stream=True)
            with open(local_file_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

            if self.is_enable_image_encrypt:
                if not self.image_file_encrypt_priv_key:
                    logger.error("[Error] No private key set, cannot decrypt encrypted image")
                    return False

                headers = response.headers
                encrypted_key = headers.get("x-tos-meta-enc-dek")
                if encrypted_key:
                    try:
                        encrypted_key_bytes = base64.b64decode(unquote(encrypted_key))
                        encrypted_key = self.image_file_encrypt_priv_key.decrypt(encrypted_key_bytes)
                        tmp_file_path = local_file_path + ".tmp"
                        decrypt_file(encrypted_key, local_file_path, tmp_file_path, 'b')
                        os.remove(local_file_path)
                        os.rename(tmp_file_path, local_file_path)
                    except Exception as e:
                        logger.error(f"[Error] Failed to decode encrypted_key: {e}")
                        traceback.print_exc()
                        return False
        except Exception as e:
            logger.error(f"[Error] Download failed: {e}")
            traceback.print_exc()
            return False
        return True
